# My First Project > 2026-05-05 2:31pm
https://universe.roboflow.com/malavikas-workspace-bk8oo/my-first-project-sm8t2

Provided by a Roboflow user
License: CC BY 4.0

